/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author laboratorio
 */
public class ServidorCozinha {
        public static void main(String[] args) {
        final int PORTA = 12345;

        try (ServerSocket servidor = new ServerSocket(PORTA)) {
            System.out.println("Cozinha iniciada. Aguardando pedidos na porta " + PORTA + "...");

            while (true) {
                Socket cliente = servidor.accept();

                new Thread(() -> {
                    try (BufferedReader entrada = new BufferedReader(
                            new InputStreamReader(cliente.getInputStream()))) {

                        String pedido;
                        System.out.println("Novo pedido recebido:");
                        while ((pedido = entrada.readLine()) != null) {
                            System.out.println(pedido);
                        }

                        System.out.println("Pedido finalizado.");
                    } catch (IOException e) {
                        System.out.println("Erro ao processar pedido: " + e.getMessage());
                    }
                }).start();
            }

        } catch (IOException e) {
            System.out.println("Erro ao iniciar o servidor: " + e.getMessage());
        }
    }
}
