/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package interfaces;

import DAO.BebidaDAO;
import DAO.ComidaDAO;
import DAO.PedidosDAO;
import DAO.SobremesaDAO;
import beans.Bebida;
import beans.Comida;
import beans.Pedido;
import beans.Sobremesa;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author gilberto, matheus e romeo.
 */
public class VisualizarCarrinhoCliente extends javax.swing.JFrame {

    /**
     * Creates new form VisualizarCarrinho
     */
    
    private static double totalPedidosConfirmados = 0; // Total acumulado
    
    public VisualizarCarrinhoCliente() {
        initComponents();
        preencherTabela();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblPedidosCarrinho = new javax.swing.JTable();
        lblTitulo = new javax.swing.JLabel();
        btnConfirmarPedido = new javax.swing.JButton();
        btnVerConta = new javax.swing.JButton();
        btnVoltarMenuPedidos = new javax.swing.JButton();
        btnLimparCarrinho = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Carrinho");

        tblPedidosCarrinho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mesa", "Nome - Comida", "Valor Total - Comidas", "Nome - Bebida", "Valor Total - Bebidas", "Nome - Sobremesa", "Valor Total - Sobremesas", "VALOR TOTAL"
            }
        ));
        jScrollPane1.setViewportView(tblPedidosCarrinho);

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        lblTitulo.setText("   CARRINHO");

        btnConfirmarPedido.setBackground(new java.awt.Color(0, 153, 153));
        btnConfirmarPedido.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnConfirmarPedido.setForeground(new java.awt.Color(255, 255, 255));
        btnConfirmarPedido.setText("Confirmar Pedido");
        btnConfirmarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarPedidoActionPerformed(evt);
            }
        });

        btnVerConta.setBackground(new java.awt.Color(102, 153, 0));
        btnVerConta.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVerConta.setText("Visualizar conta total");
        btnVerConta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerContaActionPerformed(evt);
            }
        });

        btnVoltarMenuPedidos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnVoltarMenuPedidos.setText("Fazer mais pedidos");
        btnVoltarMenuPedidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarMenuPedidosActionPerformed(evt);
            }
        });

        btnLimparCarrinho.setBackground(new java.awt.Color(255, 0, 51));
        btnLimparCarrinho.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnLimparCarrinho.setForeground(new java.awt.Color(255, 255, 255));
        btnLimparCarrinho.setText("Limpar Carrinho");
        btnLimparCarrinho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparCarrinhoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1479, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnVoltarMenuPedidos, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnVerConta, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(1137, 1137, 1137)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnConfirmarPedido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLimparCarrinho, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(61, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnLimparCarrinho, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 516, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnConfirmarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnVerConta, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(btnVoltarMenuPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnConfirmarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarPedidoActionPerformed
                                                      
        PedidosDAO pDAO = new PedidosDAO();
        List<Pedido> listaPedidos = pDAO.getPedidos();

        File arquivoCSV = new File("resumo_pedido.csv");
        List<String> linhasExistentes = new ArrayList<>();
        double somaTotalPedidos = 0;
        boolean cabeçalhoExiste = false;

        // Lê o arquivo existente (removendo linhas de total geral e identificando cabeçalho)
        if (arquivoCSV.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(arquivoCSV))) {
                String linha;
                while ((linha = reader.readLine()) != null) {
                    if (linha.startsWith("Comida;")) {
                        cabeçalhoExiste = true;
                        linhasExistentes.add(linha);
                    } else if (!linha.startsWith("- VALOR TOTAL GERAL:")) {
                        linhasExistentes.add(linha);

                        String[] partes = linha.split(";");
                        if (partes.length >= 7) {
                            try {
                                double valor = Double.parseDouble(partes[6].replace(",", "."));
                                somaTotalPedidos += valor;
                            } catch (NumberFormatException e) {
                                // Ignora se não for valor válido
                            }
                        }
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Erro ao ler o CSV: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }

        // Prepara novas linhas dos pedidos atuais
        StringBuilder novasLinhas = new StringBuilder();

        for (Pedido pedido : listaPedidos) {
            String nomeComida = pedido.getId_comida().getNome();
            String nomeBebida = pedido.getId_bebida().getNome();
            String nomeSobremesa = pedido.getId_sobremesa().getNome();

            int qtdComida = pedido.getQuantidade_comida();
            int qtdBebida = pedido.getQuantidade_bebida();
            int qtdSobremesa = pedido.getQuantidade_sobremesa();

            double totalComida = qtdComida * pedido.getId_comida().getValor();
            double totalBebida = qtdBebida * pedido.getId_bebida().getValor();
            double totalSobremesa = qtdSobremesa * pedido.getId_sobremesa().getValor();

            double totalPedido = totalComida + totalBebida + totalSobremesa;
            somaTotalPedidos += totalPedido;

            novasLinhas.append(String.format("%s;%s;%s;%d;%d;%d;%.2f\n",
                nomeComida, nomeBebida, nomeSobremesa, qtdComida, qtdBebida, qtdSobremesa, totalPedido));
        }

        // Escreve tudo novamente no arquivo
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(arquivoCSV))) {
            // Se não tiver cabeçalho, escreve
            if (!cabeçalhoExiste) {
                writer.write("Comida;Bebida;Sobremesa;Qtd Comida;Qtd Bebida;Qtd Sobremesa;Total Pedido");
                writer.newLine();
            }

            // Escreve as linhas antigas (sem total anterior)
            for (String linha : linhasExistentes) {
                writer.write(linha);
                writer.newLine();
            }

            // Escreve os novos pedidos
            writer.write(novasLinhas.toString());

            double taxaGarcom = somaTotalPedidos*0.10;
            // Escreve o novo total geral
            writer.write(String.format("- VALOR TOTAL GERAL:;%.2f\n", somaTotalPedidos+taxaGarcom));
            writer.flush();

            JOptionPane.showMessageDialog(null, "CSV atualizado com sucesso!", "Tudo certo", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Erro ao escrever no CSV: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }

        // Interface e limpeza
        JOptionPane.showMessageDialog(null, "Pedido enviado com sucesso!", "Notificação", JOptionPane.INFORMATION_MESSAGE);
        totalPedidosConfirmados += somaTotalPedidos;

        DefaultTableModel tabelaPedidosCarrinho = (DefaultTableModel) tblPedidosCarrinho.getModel();
        tabelaPedidosCarrinho.setNumRows(0);

        pDAO.excluirTodosPedidos();

    }//GEN-LAST:event_btnConfirmarPedidoActionPerformed

    private void btnVerContaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerContaActionPerformed
        FecharContaCliente fecharConta = new FecharContaCliente();
        fecharConta.setVisible(true);
    }//GEN-LAST:event_btnVerContaActionPerformed

    private void btnVoltarMenuPedidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarMenuPedidosActionPerformed
        IniciarPedidosCliente iniciarPedidos = new IniciarPedidosCliente();
        iniciarPedidos.setVisible(true);
        
        this.dispose();
    }//GEN-LAST:event_btnVoltarMenuPedidosActionPerformed

    private void btnLimparCarrinhoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparCarrinhoActionPerformed
        // TODO add your handling code here:
        PedidosDAO pDAO = new PedidosDAO();
        pDAO.excluirTodosPedidos();
        DefaultTableModel tabelaPedidosCarrinho = (DefaultTableModel) tblPedidosCarrinho.getModel();
        tabelaPedidosCarrinho.setNumRows(0);
    }//GEN-LAST:event_btnLimparCarrinhoActionPerformed

    public static double getTotalPedidosConfirmados() {
        return totalPedidosConfirmados;
    }

    public static void setTotalPedidosConfirmados(double totalPedidosConfirmados) {
        VisualizarCarrinhoCliente.totalPedidosConfirmados = totalPedidosConfirmados;
    }

    
    
   public void preencherTabela() {
    PedidosDAO pDAO = new PedidosDAO();

    // Obtendo os itens conforme o nome digitado
    List<Pedido> listaPedidos = pDAO.getPedidos();

    // Obtendo o modelo da tabela
    DefaultTableModel tabelaPedidosCarrinho = (DefaultTableModel) tblPedidosCarrinho.getModel();
    tabelaPedidosCarrinho.setNumRows(0); // Limpando a tabela antes de preencher

    // Adicionando pedidos à tabela
    for (Pedido p : listaPedidos) {
        // Calcula os valores individuais
        double totalComida = p.getId_comida().getValor() * p.getQuantidade_comida();
        double totalBebida = p.getId_bebida().getValor() * p.getQuantidade_bebida();
        double totalSobremesa = p.getId_sobremesa().getValor() * p.getQuantidade_sobremesa();

        // Calcula o valor total do pedido
        double valorTotal = totalComida + totalBebida + totalSobremesa;
        
        
        // Criando a linha da tabela
        Object[] obj = new Object[]{
            p.getMesa(),
            p.getQuantidade_comida() + "x " + p.getId_comida().getNome(), "R$ " + totalComida,
            p.getQuantidade_bebida() + "x " + p.getId_bebida().getNome(), "R$ " + totalBebida,
            p.getQuantidade_sobremesa() + "x " + p.getId_sobremesa().getNome(), "R$ " + totalSobremesa,
            "Total: R$ " + valorTotal
        };

        // Adiciona a linha na tabela
        tabelaPedidosCarrinho.addRow(obj);
    }
}


    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VisualizarCarrinhoCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VisualizarCarrinhoCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VisualizarCarrinhoCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VisualizarCarrinhoCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VisualizarCarrinhoCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConfirmarPedido;
    private javax.swing.JButton btnLimparCarrinho;
    private javax.swing.JButton btnVerConta;
    private javax.swing.JButton btnVoltarMenuPedidos;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTable tblPedidosCarrinho;
    // End of variables declaration//GEN-END:variables
}
